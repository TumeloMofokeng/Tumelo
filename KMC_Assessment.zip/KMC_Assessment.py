Python 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 07:18:10) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> A, B, C, D, E, F, G, H, I, J, J, L, M, N, O, P, Q = 19, 28, 23, 4, 78, 70, 32, 54, 32, 12, 67,90,87,6,36,12,24   # Instance variables are for data unique to each instance
>>> L = 'Sorry 90 years old cannot be assisted.'  # getting error when person is 90 years old'
>>> Q = Q + N  # Taking Q24 current age and adding the age of the person two positions in front of him which is N
>>> 
